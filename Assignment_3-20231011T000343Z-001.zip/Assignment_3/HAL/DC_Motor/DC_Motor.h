/*
 * DC_Motor.h
 *
 *  Created on: Sep 6, 2023
 *      Author: Meriam Ehab
 */

#ifndef SRC_HAL_DC_MOTOR_DC_MOTOR_H_
#define SRC_HAL_DC_MOTOR_DC_MOTOR_H_

/************************** Includes *****************************/
/*****************************************************************/

#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"
#include "../../MCAL/MGPIO/MGPIO_Interface.h"

typedef enum{
	CW,
	A_CW,
	STOP
}DC_Mode;

#define DC_MOTOR_PORT 			_GPIOA_PORT

#define DC_MOTOR_PIN_IN1		_PIN_1
#define DC_MOTOR_PIN_IN2		_PIN_2
#define DC_MOTOR_PIN_EN1		_PIN_3

void DC_Motor_Init(void);

void DC_Motor_Rotate(DC_Mode Mode);

#endif /* SRC_HAL_DC_MOTOR_DC_MOTOR_H_ */
