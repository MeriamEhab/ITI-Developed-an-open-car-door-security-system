/*
 * main.c
 *
 *  Created on: Sep 6, 2023
 *      Author: Meriam Ehab
 */


#include "MCAL/MRCC/MRCC_Int.h"
#include "MCAL/MGPIO/MGPIO_Interface.h"
#include "MCAL/MEXTI/MEXTI_Int.h"
#include "MCAL/MNVIC/MNVIC_Int.h"
#include "MCAL/MUART/MUART_Int.h"
#include "HAL/DC_Motor/DC_Motor.h"


/* FUNCTION PROTOTYPE */
void PB_Pressed(void);

/******************* MAIN FUNCTION *********************/

int main(void)
{
	/************ Clock Initialization ****************/

	MRCC_vInit();
	MRCC_vEnableClock(AHB1, RCC_GPIOA_EN);
	MRCC_vEnableClock(APB2, RCC_SYSCFG_EN);
	MRCC_vEnableClock(APB2, RCC_USART1_EN);

	/************* GPIO Configuration *****************/

	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_0, _MODE_INPUT);
	MGPIO_voidSetPullType(_GPIOA_PORT, _PIN_0, _PULL_UP);
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_4, _MODE_OUTPUT);
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_9, _MODE_ALTF);
	MGPIO_voidSetPinAltFn(_GPIOA_PORT,  _PIN_9, _ALTFN_7);
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_10, _MODE_ALTF);
	MGPIO_voidSetPinAltFn(_GPIOA_PORT,  _PIN_10, _ALTFN_7);

	/*********** DC Motor Initialization *************/

	DC_Motor_Init();

	/************* USART Configuration ****************/

	MSUART_voidInit();
	MUSART_voidEnable(1);

	/*********** Interrupt Configuration **************/

	MNVIC_vInterruptSetEnable(6);
	MNVIC_vSetGroupMode(MNVIC_G4_SG4);
	MNVIC_vSetInterruptPriority(6, 0, 0);

	MEXTI_vHWInterruptEnable(EXTI_Line_0);
	MEXTI_vSetTriggerType(EXTI_Line_0, Rising);
	MEXTI_vSetExtiConfig(EXTI_Line_0, SYSCFG_PORTA);
	MEXTI_vSetCallback(EXTI_Line_0, PB_Pressed);

	for(;;)
	{}
}

/* FUNCTION */
void PB_Pressed(void){
	u8 data = 2;
	DC_Motor_Rotate(CW);
	MGPIO_voidWriteData(_GPIOA_PORT, _PIN_4, _HIGH);
	MUSART_voidSendData(1, &data, 1);
	while(MGPIO_u8ReadData(_GPIOA_PORT, _PIN_0) == 0)
	{}
	data = 1;
	DC_Motor_Rotate(STOP);
	MGPIO_voidWriteData(_GPIOA_PORT, _PIN_4, _LOW);
	MUSART_voidSendData(1, &data, 1);
}

