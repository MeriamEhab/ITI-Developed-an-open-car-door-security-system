/*
 * main_com.c
 *
 *  Created on: Sep 6, 2023
 *      Author: Meriam Ehab
 */

#include "MCAL/MRCC/MRCC_Int.h"
#include "MCAL/MGPIO/MGPIO_Interface.h"
#include "MCAL/MEXTI/MEXTI_Int.h"
#include "MCAL/MNVIC/MNVIC_Int.h"
#include "MCAL/MUART/MUART_Int.h"
#include "HAL/DC_Motor/DC_Motor.h"

/************************ GLOBAL VARIABLES ***************************/
u8 g_DoorOpen = 1;

/******************* FUNCTION PROTOTYPE ******************/
void PB_Pressed(void);
void LED_off(void);
void LED_on(void);

/******************* MAIN FUNCTION *********************/

int main(void)
{
	u8 Data_Received;

	/************ Clock Initialization ****************/

	MRCC_vInit();
	MRCC_vEnableClock(AHB1, RCC_GPIOA_EN);
	MRCC_vEnableClock(APB2, RCC_SYSCFG_EN);
	MRCC_vEnableClock(APB2, RCC_USART1_EN);

	/************* GPIO Configuration *****************/

	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_0, _MODE_INPUT);
	MGPIO_voidSetPullType(_GPIOA_PORT, _PIN_0, _PULL_UP);
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_1, _MODE_OUTPUT);
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_9, _MODE_ALTF);
	MGPIO_voidSetPinAltFn(_GPIOA_PORT,  _PIN_9, _ALTFN_7);
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_10, _MODE_ALTF);
	MGPIO_voidSetPinAltFn(_GPIOA_PORT,  _PIN_10, _ALTFN_7);

	/************* USART Configuration ****************/

	MSUART_voidInit();
	MUSART_voidEnable(1);

	/*********** Interrupt Configuration **************/

	MNVIC_vInterruptSetEnable(6);
	MNVIC_vSetGroupMode(MNVIC_G4_SG4);
	MNVIC_vSetInterruptPriority(6, 0, 0);

	MEXTI_vHWInterruptEnable(EXTI_Line_0);
	MEXTI_vSetTriggerType(EXTI_Line_0, Rising);
	MEXTI_vSetExtiConfig(EXTI_Line_0, SYSCFG_PORTA);
	MEXTI_vSetCallback(EXTI_Line_0, PB_Pressed);

	while (1){
		Data_Received = MUSART_u8ReadData(1);
		if((Data_Received == 2) && (g_DoorOpen == 1)){
			LED_on();
		}
		else{
			LED_off();
		}
		if(MGPIO_u8ReadData(_GPIOA_PORT, _PIN_0)){
			g_DoorOpen = 1;
		}
	}
}
	/* FUNCTION */
	void PB_Pressed(void){
		g_DoorOpen = 0;
	}

	void LED_off(void){
		MGPIO_voidWriteData(_GPIOA_PORT, _PIN_1, _LOW);
	}

	void LED_on(void){
		MGPIO_voidWriteData(_GPIOA_PORT, _PIN_1, _HIGH);
	}
