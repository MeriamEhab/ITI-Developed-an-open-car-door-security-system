/*
 * main.c
 *
 *  Created on: Sep 6, 2023
 *      Author: Meriam Ehab
 */

#include "MCAL/MGPIO/MGPIO_Interface.h"
#include "MCAL/MNVIC/MNVIC_Int.h"
#include "MCAL/MRCC/MRCC_Int.h"
#include "MCAL/MUART/MUART_Interface.h"
#include "HAL/DC_Motor/DC_Motor.h"
#include "MCAL/MEXTI/MEXTI_Interface.h"

/**************************************** GLOBAL VARIABLES *********************************************/
u8	g_Car_Pressed = 0;

/***************************************** FUNCTION PROTOTYPES **********************************************/
void PB_vPressed(void);

/***************************************** MAIN FUNCTIONS **********************************************/

int main(void)
{
	/************ Clock Initialization ****************/
	MRCC_voidEnableSecuritySystem();
	MRCC_voidEnablePeripheralClock(AHB1_BUS, _PERIPHERAL_EN_GPIOA);
	MRCC_voidEnablePeripheralClock(APB2_BUS, PERIPHERAL_EN_SYSCFG);
	MRCC_voidEnablePeripheralClock(APB2_BUS, PERIPHERAL_EN_USART1);

	/************* GPIO Configuration *****************/
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_0, _MODE_INPUT);	/* PB INPUT */
	MGPIO_voidSetPullType(_GPIOA_PORT, _PIN_0, _PULL_UP);		/* PULL UP */
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_4, _MODE_OUTPUT);
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_9, _MODE_ALTF);
	MGPIO_voidSetPinAltFn(_GPIOA_PORT,  _PIN_9, _ALTFN_7);
	MGPIO_voidSetPinMode(_GPIOA_PORT,  _PIN_10, _MODE_ALTF);
	MGPIO_voidSetPinAltFn(_GPIOA_PORT,  _PIN_10, _ALTFN_7);

	/*********** DC Motor Initialization *************/
	DC_Motor_Init();

	/************* USART Configuration ****************/
	MSUART_voidInit();
	MUSART_voidEnable(1);

	/*********** Interrupt Configuration **************/
	MNVIC_voidEnableInterrupt(6);								/* EXTI0*/
	MNVIC_voidInitInterruptGroup(NVIC_GroupMode_g4s4);
	MNVIC_voidSetInterruptPriority(6, NVIC_GroupMode_g4s4,0, 0);						/* Make EXTI0 in Group 0 with Priority 0 */

	MEXTI_voidInit();
	MEXTI_voidEnableEXTI(0);
	MEXTI_voidSetSignalLatch(EXTI0 , FALLING_EDGE);
	MEXTI0_voidSetCallBack(PB_vPressed);
	MEXTI_voidSetEXTIConfiguration(EXTI0,0);

	/**************************************** LOCAL VARIABLES *********************************************/

	u8 data = 0;

	while (1){
		if(g_Car_Pressed == 1){
			data = 2;
			DC_Motor_Rotate(CW);
			MGPIO_voidWriteData(_GPIOA_PORT, _PIN_4, _HIGH);
			MUSART_u8SendData(1, &data, 1);
		}

		else{
			data = 1;
			DC_Motor_Rotate(STOP);
			MGPIO_voidWriteData(_GPIOA_PORT, _PIN_4, _LOW);
			MUSART_u8SendData(1, &data, 1);
		}
		if (MGPIO_u8ReadData(_GPIOA_PORT,  _PIN_0) == 1){
			g_Car_Pressed = 0;
		}
	}
}

void PB_vPressed(void){
	g_Car_Pressed = 1;
}

