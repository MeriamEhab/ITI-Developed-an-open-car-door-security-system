/*
 * MNVIC_Config.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Meriam Ehab
 */

#ifndef MCAL_MNVIC_MNVIC_CONFIG_H_
#define MCAL_MNVIC_MNVIC_CONFIG_H_



#endif /* MCAL_MNVIC_MNVIC_CONFIG_H_ */
