/*
 * MEXTI_Config.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Meriam Ehab
 */

#ifndef MCAL_MEXTI_MEXTI_CONFIG_H_
#define MCAL_MEXTI_MEXTI_CONFIG_H_



#endif /* MCAL_MEXTI_MEXTI_CONFIG_H_ */
