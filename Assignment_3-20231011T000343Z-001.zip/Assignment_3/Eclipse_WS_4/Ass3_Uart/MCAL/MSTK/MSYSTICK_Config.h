/*
 * MSYSTICK_Config.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Meriam Ehab
 */

#ifndef MCAL_MSTK_MSYSTICK_CONFIG_H_
#define MCAL_MSTK_MSYSTICK_CONFIG_H_



#endif /* MCAL_MSTK_MSYSTICK_CONFIG_H_ */
